import React from 'react'

const Favorites = () => {
  return (
    <div>
        <h2 className='mt-20'>Hiiiii</h2>
    </div>
  )
}

export default Favorites